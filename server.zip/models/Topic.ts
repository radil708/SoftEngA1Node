export default class Topic {
    private topic : string = "";
}